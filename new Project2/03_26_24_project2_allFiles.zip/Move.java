public class Move {
    public int value;
    public int move;

    
}
